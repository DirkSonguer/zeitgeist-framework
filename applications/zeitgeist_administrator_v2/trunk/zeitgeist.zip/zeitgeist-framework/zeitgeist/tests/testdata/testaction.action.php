<?php

class testaction implements zgGameaction
{

	public function execute($parameter, $time)
	{
		return true;
	}

}

?>