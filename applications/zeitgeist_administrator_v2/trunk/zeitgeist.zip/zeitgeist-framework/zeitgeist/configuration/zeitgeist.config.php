<?php

defined('ZEITGEIST_ACTIVE') or die();

	define('ZG_DB_DBSERVER', 'localhost');
	define('ZG_DB_USERNAME', 'root');
	define('ZG_DB_USERPASS', '');
	define('ZG_DB_DATABASE', 'zeitgeist');
	define('ZG_DB_CONFIGURATIONCACHE', 'configurationcache');

?>