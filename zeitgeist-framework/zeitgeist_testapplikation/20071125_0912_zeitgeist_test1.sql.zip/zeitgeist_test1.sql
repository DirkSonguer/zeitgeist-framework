-- phpMyAdmin SQL Dump
-- version 2.11.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 25. November 2007 um 09:12
-- Server Version: 5.0.45
-- PHP-Version: 5.2.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Datenbank: `zeitgeist_test1`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `actions`
--

CREATE TABLE `actions` (
  `action_id` int(12) NOT NULL auto_increment,
  `action_module` int(12) NOT NULL default '0',
  `action_name` varchar(30) NOT NULL default '',
  `action_description` text NOT NULL,
  `action_requiresuserright` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`action_id`),
  KEY `action_module` (`action_module`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Daten für Tabelle `actions`
--

INSERT INTO `actions` (`action_id`, `action_module`, `action_name`, `action_description`, `action_requiresuserright`) VALUES
(1, 1, 'index', 'main action', 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `configurationcache`
--

CREATE TABLE `configurationcache` (
  `configurationcache_id` int(12) NOT NULL auto_increment,
  `configurationcache_name` varchar(128) NOT NULL,
  `configurationcache_timestamp` varchar(32) NOT NULL,
  `configurationcache_content` text NOT NULL,
  PRIMARY KEY  (`configurationcache_id`),
  UNIQUE KEY `configuration_cache_modulename` (`configurationcache_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Daten für Tabelle `configurationcache`
--

INSERT INTO `configurationcache` (`configurationcache_id`, `configurationcache_name`, `configurationcache_timestamp`, `configurationcache_content`) VALUES
(1, './zeitgeist/configuration/zeitge', '1191176269', 'YTo2OntzOjY6InRhYmxlcyI7YTo5OntzOjExOiJ0YWJsZV91c2VycyI7czo1OiJ1c2VycyI7czoxNDoidGFibGVfdXNlcmRhdGEiO3M6ODoidXNlcmRhdGEiO3M6MTY6InRhYmxlX3VzZXJyaWdodHMiO3M6MTA6InVzZXJyaWdodHMiO3M6MjA6InRhYmxlX3VzZXJjaGFyYWN0ZXJzIjtzOjE0OiJ1c2VyY2hhcmFjdGVycyI7czoyNToidGFibGVfdXNlcnJpZ2h0c190b191c2VycyI7czoxOToidXNlcnJpZ2h0c190b191c2VycyI7czoxODoidGFibGVfdXNlcnNlc3Npb25zIjtzOjEyOiJ1c2Vyc2Vzc2lvbnMiO3M6MTc6InRhYmxlX3Nlc3Npb25kYXRhIjtzOjExOiJzZXNzaW9uZGF0YSI7czoxMzoidGFibGVfbW9kdWxlcyI7czo3OiJtb2R1bGVzIjtzOjEzOiJ0YWJsZV9hY3Rpb25zIjtzOjc6ImFjdGlvbnMiO31zOjc6InNlc3Npb24iO2E6MTp7czoxNToic2Vzc2lvbl9zdG9yYWdlIjtzOjg6ImRhdGFiYXNlIjt9czo4OiJ0ZW1wbGF0ZSI7YToxMjp7czoxMjoicmV3cml0ZV91cmxzIjtzOjE6IjAiO3M6MTg6InZhcmlhYmxlU3Vic3RCZWdpbiI7czo1OiI8IS0tQCI7czoxNjoidmFyaWFibGVTdWJzdEVuZCI7czo0OiJALS0+IjtzOjE1OiJibG9ja1N1YnN0QmVnaW4iO3M6NToiPCEtLSMiO3M6MTM6ImJsb2NrU3Vic3RFbmQiO3M6NToiJyMtLT4iO3M6OToibGlua0JlZ2luIjtzOjQ6IkBAe1siO3M6NzoibGlua0VuZCI7czo0OiJdfUBAIjtzOjEzOiJ2YXJpYWJsZUJlZ2luIjtzOjM6IkBAeyI7czoxMToidmFyaWFibGVFbmQiO3M6MzoifUBAIjtzOjE0OiJibG9ja09wZW5CZWdpbiI7czozMDoiPCEtLSBUZW1wbGF0ZUJlZ2luQmxvY2sgbmFtZT0iIjtzOjEyOiJibG9ja09wZW5FbmQiO3M6NToiIiAtLT4iO3M6MTA6ImJsb2NrQ2xvc2UiO3M6MjU6IjwhLS0gVGVtcGxhdGVFbmRCbG9jayAtLT4iO31zOjEyOiJldmVudGhhbmRsZXIiO2E6Mjp7czoyODoicmVxdWlyZWRfcGFyYW1ldGVyX25vdF9mb3VuZCI7czozOiI5OTkiO3M6OToibWV0aG9kX29rIjtzOjQ6InRydWUiO31zOjEyOiJlcnJvcmhhbmRsZXIiO2E6MTp7czoxNzoiZXJyb3JfcmVwb3J0bGV2ZWwiO3M6MToiMiI7fXM6MTc6InBhcmFtZXRlcnJlZ2lzdHJ5IjthOjM6e3M6MTU6InBhcmFtZXRlcl9lbWFpbCI7czo1MjoiL15bdy0rJipdKyg/Oi5bdy1fKyYqXSspKkAoPzpbdy1dKy4pK1thLXpBLVpdezIsN30kLyI7czoxMzoicGFyYW1ldGVyX3ppcCI7czoxMDoiL15kezQsNX0kLyI7czoxNjoicGFyYW1ldGVyX3N0cmluZyI7czo0OToiL15bd/zc5MT21iBdKygoWycsLi0gXVt3/NzkxPbWIF0pP1t3/NzkxPbWIF0qKSokLyI7fX0='),
(9, 'test1.ini', '1195682246', 'YTozOntzOjY6ImNyZWF0ZSI7YToyOntzOjIxOiJoYXNFeHRlcm5hbFBhcmFtZXRlcnMiO3M6NDoidHJ1ZSI7czoxNjoiZGVwYXJ0bWVudF9jb2xvciI7czo1OiJfUE9TVCI7fXM6NDoic2hvdyI7YTozOntzOjk6IlByZVNuYXBJbiI7YToyOntpOjA7czoxMDoidGVzdC5mdW5jMSI7aToxO3M6MTA6InRlc3QuZnVuYzIiO31zOjIxOiJoYXNFeHRlcm5hbFBhcmFtZXRlcnMiO3M6NDoidHJ1ZSI7czo5OiJpZF9zb3VyY2UiO3M6NDoiX0dFVCI7fXM6OToidGVtcGxhdGVzIjthOjE6e3M6NjoiY3JlYXRlIjtzOjc2OiJ0ZW1wbGF0ZXMvW1twcm9qZWN0aXZlLnByb2plY3RpdmUudGVtcGxhdGVfZGlyXV0vZGVwYXJ0bWVudHMvY3JlYXRlLnRwbC5odG1sIjt9fQ=='),
(22, './modules/main/main.ini', '1195909446', 'YToyOntzOjU6ImluZGV4IjthOjM6e3M6MjE6Imhhc0V4dGVybmFsUGFyYW1ldGVycyI7czo0OiJ0cnVlIjtzOjU6InRlc3QxIjthOjM6e3M6OToicGFyYW1ldGVyIjtzOjQ6InRydWUiO3M6Njoic291cmNlIjtzOjM6IkdFVCI7czo0OiJ0eXBlIjtzOjExOiIvXi57NCwzMn0kLyI7fXM6NToidGVzdDIiO2E6Mzp7czo5OiJwYXJhbWV0ZXIiO3M6NDoidHJ1ZSI7czo2OiJzb3VyY2UiO3M6MzoiR0VUIjtzOjQ6InR5cGUiO3M6NToiL14uJC8iO319czo0OiJzaG93IjthOjM6e3M6OToiUHJlU25hcEluIjthOjI6e2k6MDtzOjEwOiJ0ZXN0LmZ1bmMxIjtpOjE7czoxMDoidGVzdC5mdW5jMiI7fXM6MjE6Imhhc0V4dGVybmFsUGFyYW1ldGVycyI7czo0OiJ0cnVlIjtzOjk6ImlkX3NvdXJjZSI7czo0OiJfR0VUIjt9fQ=='),
(12, './zeitgeist/configuration/zeitgeist.ini', '1195893032', 'YTo2OntzOjY6InRhYmxlcyI7YToxMDp7czoxMToidGFibGVfdXNlcnMiO3M6NToidXNlcnMiO3M6MTQ6InRhYmxlX3VzZXJkYXRhIjtzOjg6InVzZXJkYXRhIjtzOjE2OiJ0YWJsZV91c2VycmlnaHRzIjtzOjEwOiJ1c2VycmlnaHRzIjtzOjIwOiJ0YWJsZV91c2VyY2hhcmFjdGVycyI7czoxNDoidXNlcmNoYXJhY3RlcnMiO3M6MjU6InRhYmxlX3VzZXJyaWdodHNfdG9fdXNlcnMiO3M6MTk6InVzZXJyaWdodHNfdG9fdXNlcnMiO3M6MTg6InRhYmxlX3VzZXJzZXNzaW9ucyI7czoxMjoidXNlcnNlc3Npb25zIjtzOjE3OiJ0YWJsZV9zZXNzaW9uZGF0YSI7czoxMToic2Vzc2lvbmRhdGEiO3M6MTM6InRhYmxlX21vZHVsZXMiO3M6NzoibW9kdWxlcyI7czoxMzoidGFibGVfYWN0aW9ucyI7czo3OiJhY3Rpb25zIjtzOjE5OiJ0YWJsZV90ZW1wbGF0ZWNhY2hlIjtzOjEzOiJ0ZW1wbGF0ZWNhY2hlIjt9czo3OiJzZXNzaW9uIjthOjE6e3M6MTU6InNlc3Npb25fc3RvcmFnZSI7czo4OiJkYXRhYmFzZSI7fXM6ODoidGVtcGxhdGUiO2E6MTI6e3M6MTI6InJld3JpdGVfdXJscyI7czoxOiIwIjtzOjE4OiJ2YXJpYWJsZVN1YnN0QmVnaW4iO3M6NToiPCEtLUAiO3M6MTY6InZhcmlhYmxlU3Vic3RFbmQiO3M6NDoiQC0tPiI7czoxNToiYmxvY2tTdWJzdEJlZ2luIjtzOjU6IjwhLS0jIjtzOjEzOiJibG9ja1N1YnN0RW5kIjtzOjU6IicjLS0+IjtzOjk6ImxpbmtCZWdpbiI7czo0OiJAQHtbIjtzOjc6ImxpbmtFbmQiO3M6NDoiXX1AQCI7czoxMzoidmFyaWFibGVCZWdpbiI7czozOiJAQHsiO3M6MTE6InZhcmlhYmxlRW5kIjtzOjM6In1AQCI7czoxNDoiYmxvY2tPcGVuQmVnaW4iO3M6MzA6IjwhLS0gVGVtcGxhdGVCZWdpbkJsb2NrIG5hbWU9IiI7czoxMjoiYmxvY2tPcGVuRW5kIjtzOjU6IiIgLS0+IjtzOjEwOiJibG9ja0Nsb3NlIjtzOjI1OiI8IS0tIFRlbXBsYXRlRW5kQmxvY2sgLS0+Ijt9czoxMjoiZXZlbnRoYW5kbGVyIjthOjM6e3M6MjQ6Im5vX3VzZXJyaWdodHNfZm9yX2FjdGlvbiI7czoxOiIyIjtzOjI4OiJyZXF1aXJlZF9wYXJhbWV0ZXJfbm90X2ZvdW5kIjtzOjM6Ijk5OSI7czo5OiJtZXRob2Rfb2siO3M6NDoidHJ1ZSI7fXM6MTI6ImVycm9yaGFuZGxlciI7YToxOntzOjE3OiJlcnJvcl9yZXBvcnRsZXZlbCI7czoxOiIyIjt9czoxNzoicGFyYW1ldGVycmVnaXN0cnkiO2E6Mzp7czoxNToicGFyYW1ldGVyX2VtYWlsIjtzOjUyOiIvXlt3LSsmKl0rKD86Llt3LV8rJipdKykqQCg/Olt3LV0rLikrW2EtekEtWl17Miw3fSQvIjtzOjEzOiJwYXJhbWV0ZXJfemlwIjtzOjEwOiIvXmR7NCw1fSQvIjtzOjE2OiJwYXJhbWV0ZXJfc3RyaW5nIjtzOjQ5OiIvXlt3/NzkxPbWIF0rKChbJywuLSBdW3f83OTE9tYgXSk/W3f83OTE9tYgXSopKiQvIjt9fQ==');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `modules`
--

CREATE TABLE `modules` (
  `module_id` int(12) NOT NULL auto_increment,
  `module_name` varchar(30) NOT NULL default '',
  `module_desription` text NOT NULL,
  `module_active` tinyint(1) NOT NULL default '0',
  `module_requiresuserright` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`module_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Daten für Tabelle `modules`
--

INSERT INTO `modules` (`module_id`, `module_name`, `module_desription`, `module_active`, `module_requiresuserright`) VALUES
(1, 'main', 'Core module. This module is active by default. It can not be deactivated nor uninstalled.\r\nThe module handles all the usual core actions like user handling, login/ -out etc.', 1, 0),
(2, 'showhtml', 'Just shows a HTML page', 1, 0),
(3, 'carmap', 'This module display a Google Maps Mashup with all the cars sold by Hirch.', 1, 0),
(4, 'contact', 'handle contact forms', 1, 0),
(5, 'newsletter', '(un)subscribt the newsletter', 1, 0),
(6, 'partner', 'internal partner area', 1, 0),
(7, 'dataserver', '', 1, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `preferences`
--

CREATE TABLE `preferences` (
  `preference_id` int(12) NOT NULL auto_increment,
  `preference_key` varchar(30) NOT NULL default '',
  `preference_value` varchar(30) NOT NULL default '',
  `preference_description` text,
  `preference_order` int(5) NOT NULL default '0',
  PRIMARY KEY  (`preference_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `preferences`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `preferences_to_users`
--

CREATE TABLE `preferences_to_users` (
  `preferencesusers_id` int(12) NOT NULL auto_increment,
  `preferencesusers_user` int(12) NOT NULL default '0',
  `preferencesusers_preference` int(12) NOT NULL default '0',
  PRIMARY KEY  (`preferencesusers_id`),
  KEY `preferencesusers_user` (`preferencesusers_user`),
  KEY `preferencesusers_preference` (`preferencesusers_preference`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `preferences_to_users`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `sessiondata`
--

CREATE TABLE `sessiondata` (
  `sessiondata_id` varchar(32) NOT NULL,
  `sessiondata_created` int(11) NOT NULL default '0',
  `sessiondata_lastupdate` int(11) NOT NULL default '0',
  `sessiondata_content` text character set utf8 NOT NULL,
  `sessiondata_ip` varchar(15) NOT NULL,
  PRIMARY KEY  (`sessiondata_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `sessiondata`
--

INSERT INTO `sessiondata` (`sessiondata_id`, `sessiondata_created`, `sessiondata_lastupdate`, `sessiondata_content`, `sessiondata_ip`) VALUES
('4a177cf9e0d4e2c47b23c6afe0164c6f', 1195978308, 1195978308, 'user_userid|s:1:"1";user_key|N;userrights|a:1:{i:1;s:1:"1";}userdata|a:24:{s:11:"userdata_id";s:1:"3";s:13:"userdata_user";s:1:"1";s:18:"userdata_firstname";s:4:"Dirk";s:17:"userdata_lastname";s:7:"Songür";s:17:"userdata_birthday";N;s:15:"userdata_active";s:1:"1";s:16:"userdata_company";s:14:"Sitewards GmbH";s:15:"userdata_email1";s:21:"songuer@sitewards.com";s:15:"userdata_email2";N;s:12:"userdata_url";s:24:"http://www.sitewards.com";s:15:"userdata_phone1";s:13:"06151 3964703";s:15:"userdata_phone2";N;s:12:"userdata_fax";s:13:"06151 3964706";s:15:"userdata_mobile";N;s:17:"userdata_address1";s:22:"Pallaswiesenstraße 63";s:17:"userdata_address2";s:12:"Hinterhaus A";s:13:"userdata_city";s:9:"Darmstadt";s:12:"userdata_zip";s:5:"64293";s:14:"userdata_state";N;s:16:"userdata_country";s:11:"Deutschland";s:11:"userdata_im";s:17:"sitewards_songuer";s:20:"userdata_description";s:17:"Dies ist ein Test";s:19:"userdata_priceaddon";s:5:"10000";s:18:"userdata_timestamp";s:19:"2007-10-22 11:31:28";}', '127.0.0.1'),
('43f0a32e46d6da3d63b9ed44d8f6e74e', 1195896044, 1195910372, 'user_userid|s:1:"1";user_key|N;userrights|a:1:{i:1;s:1:"1";}userdata|a:24:{s:11:"userdata_id";s:1:"3";s:13:"userdata_user";s:1:"1";s:18:"userdata_firstname";s:4:"Dirk";s:17:"userdata_lastname";s:7:"Songür";s:17:"userdata_birthday";N;s:15:"userdata_active";s:1:"1";s:16:"userdata_company";s:14:"Sitewards GmbH";s:15:"userdata_email1";s:21:"songuer@sitewards.com";s:15:"userdata_email2";N;s:12:"userdata_url";s:24:"http://www.sitewards.com";s:15:"userdata_phone1";s:13:"06151 3964703";s:15:"userdata_phone2";N;s:12:"userdata_fax";s:13:"06151 3964706";s:15:"userdata_mobile";N;s:17:"userdata_address1";s:22:"Pallaswiesenstraße 63";s:17:"userdata_address2";s:12:"Hinterhaus A";s:13:"userdata_city";s:9:"Darmstadt";s:12:"userdata_zip";s:5:"64293";s:14:"userdata_state";N;s:16:"userdata_country";s:11:"Deutschland";s:11:"userdata_im";s:17:"sitewards_songuer";s:20:"userdata_description";s:17:"Dies ist ein Test";s:19:"userdata_priceaddon";s:5:"10000";s:18:"userdata_timestamp";s:19:"2007-10-22 11:31:28";}', '127.0.0.1');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `templatecache`
--

CREATE TABLE `templatecache` (
  `templatecache_id` int(12) NOT NULL auto_increment,
  `templatecache_name` varchar(128) collate latin1_general_ci NOT NULL,
  `templatecache_timestamp` varchar(32) collate latin1_general_ci NOT NULL,
  `templatecache_content` text collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`templatecache_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=6 ;

--
-- Daten für Tabelle `templatecache`
--

INSERT INTO `templatecache` (`templatecache_id`, `templatecache_name`, `templatecache_timestamp`, `templatecache_content`) VALUES
(5, 'test.tpl.html', '1195682246', 'YTo0OntzOjQ6ImZpbGUiO3M6MTM6InRlc3QudHBsLmh0bWwiO3M6NzoiY29udGVudCI7czo4OTg6IjwhRE9DVFlQRSBodG1sIFBVQkxJQyAiLS8vVzNDLy9EVEQgWEhUTUwgMS4wIFRyYW5zaXRpb25hbC8vRU4iICJodHRwOi8vd3d3LnczLm9yZy9UUi94aHRtbDEvRFREL3hodG1sMS10cmFuc2l0aW9uYWwuZHRkIj4NCjxodG1sIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hodG1sIj48IS0tIEluc3RhbmNlQmVnaW4gdGVtcGxhdGU9Ii9UZW1wbGF0ZXMvbWFzdGVyLmR3dCIgY29kZU91dHNpZGVIVE1MSXNMb2NrZWQ9ImZhbHNlIiAtLT4NCjxoZWFkPg0KPG1ldGEgaHR0cC1lcXVpdj0iQ29udGVudC1UeXBlIiBjb250ZW50PSJ0ZXh0L2h0bWw7IGNoYXJzZXQ9dXRmLTgiIC8+DQo8IS0tIEluc3RhbmNlQmVnaW5FZGl0YWJsZSBuYW1lPSJkb2N0aXRsZSIgLS0+DQo8IS0tI3RpdGxlJyMtLT4NCjwhLS0gSW5zdGFuY2VFbmRFZGl0YWJsZSAtLT4NCg0KCTxsaW5rIHJlbD0ic3R5bGVzaGVldCIgdHlwZT0idGV4dC9jc3MiIGhyZWY9ImxheW91dC9mbG9vdy5jc3MiIC8+DQoJDQo8IS0tIEluc3RhbmNlQmVnaW5FZGl0YWJsZSBuYW1lPSJoZWFkIiAtLT4NCjwhLS0gSW5zdGFuY2VFbmRFZGl0YWJsZSAtLT4NCg0KPC9oZWFkPg0KDQo8Ym9keT4NCg0KPHA+PGEgaHJlZj0iaW5kZXgucGhwP21vZHVsZT1jb3JlJmFjdGlvbj1tYWluIj5ob21lPC9hPjwvcD4NCg0KPGgxPlplaXRnZWlzdCBUZW1wbGF0ZS1UZXN0PC9oMT4NCg0KPCEtLSBJbnN0YW5jZUJlZ2luRWRpdGFibGUgbmFtZT0ic3VibWVudSIgLS0+DQo8IS0tI21lbnUxJyMtLT4NCjwhLS0gSW5zdGFuY2VFbmRFZGl0YWJsZSAtLT4NCg0KPCEtLSNtZXNzYWdlJyMtLT4NCg0KPHA+VGVtcGxhdGUgZ2VsYWRlbjwvcD4NCg0KPCEtLSNtYWluJyMtLT4NCg0KPC9ib2R5Pg0KPCEtLSBJbnN0YW5jZUVuZCAtLT48L2h0bWw+DQoiO3M6NjoiYmxvY2tzIjthOjU6e3M6NToidGl0bGUiO086MTU6InpnVGVtcGxhdGVCbG9jayI6NDp7czoxNDoiY3VycmVudENvbnRlbnQiO3M6MzM6Ig0KPHRpdGxlPjwhLS1AdGl0bGVALS0+PC90aXRsZT4NCiI7czoxNToib3JpZ2luYWxDb250ZW50IjtzOjMwOiINCjx0aXRsZT5AQHt0aXRsZX1AQDwvdGl0bGU+DQoiO3M6MTE6ImJsb2NrUGFyZW50IjtOO3M6MTQ6ImJsb2NrVmFyaWFibGVzIjthOjE6e3M6NToidGl0bGUiO3M6MTQ6IjwhLS1AdGl0bGVALS0+Ijt9fXM6NToibWVudTIiO086MTU6InpnVGVtcGxhdGVCbG9jayI6NTp7czoxNDoiY3VycmVudENvbnRlbnQiO3M6MTI6Ig0Kc3ViYmxvY2sNCiI7czoxNToib3JpZ2luYWxDb250ZW50IjtzOjEyOiINCnN1YmJsb2NrDQoiO3M6MTE6ImJsb2NrUGFyZW50IjtOO3M6MTQ6ImJsb2NrVmFyaWFibGVzIjtOO3M6NjoicGFyZW50IjtzOjU6Im1lbnUxIjt9czo1OiJtZW51MSI7TzoxNToiemdUZW1wbGF0ZUJsb2NrIjo0OntzOjE0OiJjdXJyZW50Q29udGVudCI7czo0NDoiDQptYWluYmxvY2sgMQ0KPCEtLSNtZW51MicjLS0+DQptYWluYmxvY2syDQoiO3M6MTU6Im9yaWdpbmFsQ29udGVudCI7czo0NDoiDQptYWluYmxvY2sgMQ0KPCEtLSNtZW51MicjLS0+DQptYWluYmxvY2syDQoiO3M6MTE6ImJsb2NrUGFyZW50IjtOO3M6MTQ6ImJsb2NrVmFyaWFibGVzIjtOO31zOjc6Im1lc3NhZ2UiO086MTU6InpnVGVtcGxhdGVCbG9jayI6NDp7czoxNDoiY3VycmVudENvbnRlbnQiO3M6Mzc6IjxwIGNsYXNzPSJlcnJvciI+PCEtLUBtZXNzYWdlQC0tPjwvcD4iO3M6MTU6Im9yaWdpbmFsQ29udGVudCI7czozNDoiPHAgY2xhc3M9ImVycm9yIj5AQHttZXNzYWdlfUBAPC9wPiI7czoxMToiYmxvY2tQYXJlbnQiO047czoxNDoiYmxvY2tWYXJpYWJsZXMiO2E6MTp7czo3OiJtZXNzYWdlIjtzOjE2OiI8IS0tQG1lc3NhZ2VALS0+Ijt9fXM6NDoibWFpbiI7TzoxNToiemdUZW1wbGF0ZUJsb2NrIjo0OntzOjE0OiJjdXJyZW50Q29udGVudCI7czo0MDoiDQo8cD5EdXJjaGdhbmc6IDwhLS1AZHVyY2hnYW5nQC0tPjwvcD4NCiI7czoxNToib3JpZ2luYWxDb250ZW50IjtzOjM3OiINCjxwPkR1cmNoZ2FuZzogQEB7ZHVyY2hnYW5nfUBAPC9wPg0KIjtzOjExOiJibG9ja1BhcmVudCI7TjtzOjE0OiJibG9ja1ZhcmlhYmxlcyI7YToxOntzOjk6ImR1cmNoZ2FuZyI7czoxODoiPCEtLUBkdXJjaGdhbmdALS0+Ijt9fX1zOjk6InZhcmlhYmxlcyI7YTozOntzOjU6InRpdGxlIjtPOjE4OiJ6Z1RlbXBsYXRlVmFyaWFibGUiOjI6e3M6MTQ6ImN1cnJlbnRDb250ZW50IjtOO3M6MTQ6ImRlZmF1bHRDb250ZW50IjtOO31zOjc6Im1lc3NhZ2UiO086MTg6InpnVGVtcGxhdGVWYXJpYWJsZSI6Mjp7czoxNDoiY3VycmVudENvbnRlbnQiO047czoxNDoiZGVmYXVsdENvbnRlbnQiO047fXM6OToiZHVyY2hnYW5nIjtPOjE4OiJ6Z1RlbXBsYXRlVmFyaWFibGUiOjI6e3M6MTQ6ImN1cnJlbnRDb250ZW50IjtOO3M6MTQ6ImRlZmF1bHRDb250ZW50IjtOO319fQ==');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `userdata`
--

CREATE TABLE `userdata` (
  `userdata_id` int(12) NOT NULL auto_increment,
  `userdata_user` int(12) NOT NULL default '0',
  `userdata_firstname` varchar(30) default NULL,
  `userdata_lastname` varchar(30) NOT NULL default '',
  `userdata_birthday` date default NULL,
  `userdata_active` tinyint(1) NOT NULL default '1',
  `userdata_company` varchar(128) default NULL,
  `userdata_email1` varchar(100) default NULL,
  `userdata_email2` varchar(100) default NULL,
  `userdata_url` varchar(100) default NULL,
  `userdata_phone1` varchar(20) default NULL,
  `userdata_phone2` varchar(20) default NULL,
  `userdata_fax` varchar(20) default NULL,
  `userdata_mobile` varchar(20) default NULL,
  `userdata_address1` varchar(60) default NULL,
  `userdata_address2` varchar(60) default NULL,
  `userdata_city` varchar(30) default NULL,
  `userdata_zip` varchar(10) default NULL,
  `userdata_state` varchar(30) default NULL,
  `userdata_country` varchar(30) default NULL,
  `userdata_im` varchar(255) default NULL,
  `userdata_description` text,
  `userdata_priceaddon` double NOT NULL,
  `userdata_timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`userdata_id`),
  KEY `userdata_user` (`userdata_user`),
  KEY `userdata_company` (`userdata_company`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Daten für Tabelle `userdata`
--

INSERT INTO `userdata` (`userdata_id`, `userdata_user`, `userdata_firstname`, `userdata_lastname`, `userdata_birthday`, `userdata_active`, `userdata_company`, `userdata_email1`, `userdata_email2`, `userdata_url`, `userdata_phone1`, `userdata_phone2`, `userdata_fax`, `userdata_mobile`, `userdata_address1`, `userdata_address2`, `userdata_city`, `userdata_zip`, `userdata_state`, `userdata_country`, `userdata_im`, `userdata_description`, `userdata_priceaddon`, `userdata_timestamp`) VALUES
(3, 1, 'Dirk', 'Songür', NULL, 1, 'Sitewards GmbH', 'songuer@sitewards.com', NULL, 'http://www.sitewards.com', '06151 3964703', NULL, '06151 3964706', NULL, 'Pallaswiesenstraße 63', 'Hinterhaus A', 'Darmstadt', '64293', NULL, 'Deutschland', 'sitewards_songuer', 'Dies ist ein Test', 10000, '2007-10-22 11:31:28');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `userrights`
--

CREATE TABLE `userrights` (
  `userright_id` int(12) NOT NULL auto_increment,
  `userright_action` int(12) NOT NULL default '0',
  `userright_user` int(12) NOT NULL default '0',
  PRIMARY KEY  (`userright_id`),
  KEY `userright_action` (`userright_action`),
  KEY `userright_user` (`userright_user`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Daten für Tabelle `userrights`
--

INSERT INTO `userrights` (`userright_id`, `userright_action`, `userright_user`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `userroles`
--

CREATE TABLE `userroles` (
  `userrole_id` int(12) NOT NULL auto_increment,
  `userrole_name` varchar(30) NOT NULL default '',
  `userrole_description` text,
  PRIMARY KEY  (`userrole_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Daten für Tabelle `userroles`
--

INSERT INTO `userroles` (`userrole_id`, `userrole_name`, `userrole_description`) VALUES
(1, 'Manager', NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `userroles_to_actions`
--

CREATE TABLE `userroles_to_actions` (
  `userroleaction_id` int(12) NOT NULL auto_increment,
  `userroleaction_userrole` int(12) NOT NULL default '0',
  `userroleaction_action` int(12) NOT NULL default '0',
  PRIMARY KEY  (`userroleaction_id`),
  KEY `userroleright_userrole` (`userroleaction_userrole`),
  KEY `userroleright_userright` (`userroleaction_action`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `userroles_to_actions`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `userroles_to_users`
--

CREATE TABLE `userroles_to_users` (
  `userroleuser_id` int(12) NOT NULL auto_increment,
  `userroleuser_userrole` int(12) NOT NULL default '0',
  `userroleuser_user` int(12) NOT NULL default '0',
  PRIMARY KEY  (`userroleuser_id`),
  KEY `userroleuser_userrole` (`userroleuser_userrole`),
  KEY `userroleuser_user` (`userroleuser_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `userroles_to_users`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `users`
--

CREATE TABLE `users` (
  `user_id` int(12) NOT NULL auto_increment,
  `user_username` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL default '',
  `user_key` varchar(64) default NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Daten für Tabelle `users`
--

INSERT INTO `users` (`user_id`, `user_username`, `user_password`, `user_key`) VALUES
(1, 'songuer', 'd883c0b2d0d8b1581838297ea11e4bbc', NULL);
